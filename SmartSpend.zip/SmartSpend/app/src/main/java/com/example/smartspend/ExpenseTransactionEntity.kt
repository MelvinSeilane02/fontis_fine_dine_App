package com.example.smartspend

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "expense_transactions")
data class ExpenseTransactionEntity (
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String = UtilityFun.getCurrentDate(),
    val transactionDate: String,
    val category: String,
    val repeat: String,
    val amount: String,
    val description: String,
    val userId: String //Important: associate each transaction with a Firebase user
)

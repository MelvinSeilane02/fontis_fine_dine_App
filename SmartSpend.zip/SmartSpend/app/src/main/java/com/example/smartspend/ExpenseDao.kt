package com.example.smartspend

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ExpenseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(transaction: ExpenseTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenses(transactions: List<ExpenseTransactionEntity>)

    @Query("SELECT * FROM expense_transactions ORDER BY id DESC")
    fun getAllExpense(): LiveData<List<ExpenseTransactionEntity>>

    @Query("SELECT * FROM expense_transactions WHERE userId = :userId")
    suspend fun getExpenseByUser(userId: String): List<ExpenseTransactionEntity>

    @Query("DELETE FROM expense_transactions WHERE id = :transactionId")
    suspend fun deleteExpenseById(transactionId: Int)
}
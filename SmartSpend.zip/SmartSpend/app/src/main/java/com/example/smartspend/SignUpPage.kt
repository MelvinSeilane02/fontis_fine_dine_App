package com.example.smartspend

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class SignUpPage : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        auth = FirebaseAuth.getInstance()

        val usernameField = findViewById<EditText>(R.id.username)
        val emailField = findViewById<EditText>(R.id.userEmail)
        val passwordField = findViewById<EditText>(R.id.newPassword)
        val confirmPasswordField = findViewById<EditText>(R.id.confirmPassword)
        val signUpBtn = findViewById<Button>(R.id.sign_up_btn)
        val signInLink = findViewById<Button>(R.id.SignInLink)

        signUpBtn.setOnClickListener {
            val username = usernameField.text.toString().trim()
            val email = emailField.text.toString().trim()
            val password = passwordField.text.toString().trim()
            val confirmPassword = confirmPasswordField.text.toString().trim()

            // Validate user input
            when {
                username.isEmpty() -> showToast("Please enter a username")
                email.isEmpty() -> showToast("Please enter an email address")
                password.isEmpty() -> showToast("Please enter a password")
                confirmPassword.isEmpty() -> showToast("Please confirm your password")
                password != confirmPassword -> showToast("Passwords do not match")
                password.length < 6 -> showToast("Password must be at least 6 characters long")
                else -> registerUser(username, email, password)
            }
        }

        signInLink.setOnClickListener {
            startActivity(Intent(this, SignIn::class.java))
        }
    }

    private fun registerUser(username: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        val database = FirebaseDatabase.getInstance().getReference("Users")
                        val userMap = mapOf(
                            "userId" to userId,
                            "username" to username,
                            "email" to email
                        )
                        database.child(userId).setValue(userMap)
                            .addOnCompleteListener { saveTask ->
                                if (saveTask.isSuccessful) {
                                    showToast("Sign Up Successful!")
                                    startActivity(Intent(this, SignIn::class.java))
                                    finish()
                                } else {
                                    showToast("Database Error: ${saveTask.exception?.message}")
                                }
                            }
                    } else {
                        showToast("Unexpected error: User ID is null")
                    }
                } else {
                    showToast("Sign Up Failed: ${task.exception?.message}")
                }
            }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}

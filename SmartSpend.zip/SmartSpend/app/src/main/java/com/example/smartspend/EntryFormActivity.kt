package com.example.smartspend

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.Calendar

class EntryFormActivity : AppCompatActivity() {

    private lateinit var incomeBtn: Button
    private lateinit var expenseBtn: Button
    private lateinit var incomeForm: View
    private lateinit var expenseForm: View

    // Income form fields
    private lateinit var incomeAmountInput: AutoCompleteTextView
    private lateinit var incomeDateInput: AutoCompleteTextView
    private lateinit var incomeCategoryInput: AutoCompleteTextView
    private lateinit var incomeRecurringInput: AutoCompleteTextView
    private lateinit var incomeAccountInput: AutoCompleteTextView
    private lateinit var incomeDescriptionInput: EditText

    // Expense form fields
    private lateinit var expenseAmountInput: AutoCompleteTextView
    private lateinit var expenseDateInput: AutoCompleteTextView
    private lateinit var expenseCategoryInput: AutoCompleteTextView
    private lateinit var expenseDescriptionInput: EditText

    private val tempTransactionList = mutableListOf<Map<String, Any>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entry_form)  // Combined layout XML

        // Buttons to switch forms
        incomeBtn = findViewById(R.id.income_btn)
        expenseBtn = findViewById(R.id.expense_btn)

        // Form containers
        incomeForm = findViewById(R.id.incomeForm)
        expenseForm = findViewById(R.id.expenseForm)

        // Income inputs
        incomeAmountInput = findViewById(R.id.amountInput)
        incomeDateInput = findViewById(R.id.dateInput)
        incomeCategoryInput = findViewById(R.id.incomeCategoryInput)
        incomeRecurringInput = findViewById(R.id.recurringTransactInput)
        incomeAccountInput = findViewById(R.id.accountTypeInput)
        incomeDescriptionInput = findViewById(R.id.descrip_input)

        // Expense inputs
        expenseAmountInput = findViewById(R.id.expenseAmountInput)
        expenseDateInput = findViewById(R.id.expenseDateInput)
        expenseCategoryInput = findViewById(R.id.expenseCategoryInput)
        expenseDescriptionInput = findViewById(R.id.expenseDescripInput)

        setupDropdowns()
        setupDatePickers()

        showIncomeForm()

        incomeBtn.setOnClickListener { showIncomeForm() }
        expenseBtn.setOnClickListener { showExpenseForm() }
    }

    private fun showIncomeForm() {
        incomeForm.visibility = View.VISIBLE
        expenseForm.visibility = View.GONE
    }

    private fun showExpenseForm() {
        expenseForm.visibility = View.VISIBLE
        incomeForm.visibility = View.GONE
    }

    private fun setupDropdowns() {
        val incomeCategories = listOf("Primary Income", "Side Hustle", "Other")
        val expenseCategories = listOf("Transport", "Groceries", "Entertainment")
        val recurringOptions = listOf("None", "Daily", "Weekly", "Monthly", "Yearly")
        val accountTypes = listOf("Main Account", "Savings Account", "Other")

        incomeCategoryInput.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, incomeCategories)
        )
        expenseCategoryInput.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, expenseCategories)
        )
        incomeRecurringInput.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, recurringOptions)
        )
        incomeAccountInput.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, accountTypes)
        )
    }

    private fun setupDatePickers() {
        val calendar = Calendar.getInstance()

        val dateListener = { input: AutoCompleteTextView ->
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            DatePickerDialog(this, { _, y, m, d ->
                input.setText(String.format("%02d/%02d/%04d", d, m + 1, y))
            }, year, month, day).show()
        }

        incomeDateInput.setOnClickListener { dateListener(incomeDateInput) }
        expenseDateInput.setOnClickListener { dateListener(expenseDateInput) }
    }

    // ----- Income form methods -----

    fun addIncome(view: View) {
        val amount = incomeAmountInput.text.toString()
        val category = incomeCategoryInput.text.toString()
        val date = incomeDateInput.text.toString()
        val recurring = incomeRecurringInput.text.toString()
        val description = incomeDescriptionInput.text.toString()
        val account = incomeAccountInput.text.toString()

        if (amount.isBlank() || category.isBlank() || date.isBlank()) {
            Toast.makeText(this, "Please fill in all required income fields", Toast.LENGTH_SHORT).show()
            return
        }

        val incomeTransaction = hashMapOf(
            "type" to "income",
            "amount" to amount,
            "category" to category,
            "date" to date,
            "description" to description,
            "recurring" to recurring,
            "accountType" to account,
            "timestamp" to System.currentTimeMillis()
        )

        tempTransactionList.add(incomeTransaction)
        Toast.makeText(this, "Income added ✅", Toast.LENGTH_SHORT).show()

        clearIncomeForm()
    }

    private fun clearIncomeForm() {
        incomeAmountInput.setText("")
        incomeDateInput.setText("")
        incomeCategoryInput.setText("")
        incomeRecurringInput.setText("")
        incomeAccountInput.setText("")
        incomeDescriptionInput.setText("")
    }

    // ----- Expense form methods -----

    fun addExpense(view: View) {
        val amount = expenseAmountInput.text.toString()
        val category = expenseCategoryInput.text.toString()
        val date = expenseDateInput.text.toString()
        val description = expenseDescriptionInput.text.toString()

        if (amount.isBlank() || category.isBlank() || date.isBlank()) {
            Toast.makeText(this, "Please fill in all required expense fields", Toast.LENGTH_SHORT).show()
            return
        }

        val expenseTransaction = hashMapOf(
            "type" to "expense",
            "amount" to amount,
            "category" to category,
            "date" to date,
            "description" to description,
            "timestamp" to System.currentTimeMillis()
        )

        tempTransactionList.add(expenseTransaction)
        Toast.makeText(this, "Expense added ✅", Toast.LENGTH_SHORT).show()

        clearExpenseForm()
    }

    private fun clearExpenseForm() {
        expenseAmountInput.setText("")
        expenseDateInput.setText("")
        expenseCategoryInput.setText("")
        expenseDescriptionInput.setText("")
    }

    // ----- Save to Firebase -----

    fun saveToFirebase(view: View) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        if (userId == null) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, MainActivity::class.java))
            return
        }

        val db = Firebase.firestore
        val userRef = db.collection("users").document(userId).collection("transactions")
        val batch = db.batch()

        tempTransactionList.forEach { transaction ->
            val docRef = userRef.document()
            batch.set(docRef, transaction)
        }

        batch.commit().addOnSuccessListener {
            Toast.makeText(this, "Saved to Firebase 🎉", Toast.LENGTH_SHORT).show()
            tempTransactionList.clear()
        }.addOnFailureListener {
            Toast.makeText(this, "Failed to save ❌", Toast.LENGTH_SHORT).show()
        }




    }
    //navigations
    fun goto_graph(view: View) {
        startActivity(Intent(this, ErrorPage::class.java))
        finish()
    }

    fun goto_lst(view: View) {
        startActivity(Intent(this, TransLstNdFilteringActivity::class.java))
        finish()
    }

    fun goto_rewards(view: View) {
        startActivity(Intent(this, ErrorPage::class.java))
        finish()
    }
}

package com.example.smartspend

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class SignIn : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        auth = FirebaseAuth.getInstance()

        val emailField = findViewById<EditText>(R.id.userEmail)
        val passwordField = findViewById<EditText>(R.id.newPassword)
        val loginBtn = findViewById<Button>(R.id.sign_in_btn)
        val signUpLink = findViewById<Button>(R.id.SignUpLink)

        loginBtn.setOnClickListener {
            val email = emailField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            when {
                email.isEmpty() -> showToast("Please enter your email")
                password.isEmpty() -> showToast("Please enter your password")
                else -> signInUser(email, password)
            }
        }

        signUpLink.setOnClickListener {
            startActivity(Intent(this, SignUpPage::class.java))
        }
    }

    private fun signInUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    showToast("Login successful")
                    startActivity(Intent(this, MainActivity_dashboard::class.java))
                    finish()
                } else {
                    showToast("Login failed: ${task.exception?.message}")
                }
            }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}

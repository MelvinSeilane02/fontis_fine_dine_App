package com.example.smartspend

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity_dashboard : AppCompatActivity() {

    private lateinit var mainAccount: EditText
    private lateinit var savingsAccount: EditText
    private lateinit var summaryAmt: TextView
    private lateinit var backBtn: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_dashboard)

        // Initialize views
        mainAccount = findViewById(R.id.main_acc_amt)
        savingsAccount = findViewById(R.id.edit_savings_input)
        summaryAmt = findViewById(R.id.total_amount)
        backBtn = findViewById(R.id.LogoutBtn)

        backBtn.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        val db = AppDatabase.getDatabase(this)
        val expenses = db.expenseDao().getAllExpense()
        val income = db.incomeDao().getAllIncome()

        db.expenseDao().getAllExpense().observe(this) { list ->
            // just observe — no need to show
            println("Expenses loaded: ${list.size}") // this line keeps DB alive
        }

        db.incomeDao().getAllIncome().observe(this) { list ->
            // update UI here
        }
    }

    private fun sumAccounts(): Double {
        val main = mainAccount.text.toString().trim().toDoubleOrNull() ?: 0.0
        val savings = savingsAccount.text.toString().trim().toDoubleOrNull() ?: 0.0
        return main + savings
    }

    fun updateSummary(view: View) {
        val total = sumAccounts()
        summaryAmt.text = total.toString()
        Toast.makeText(this, "Accounts updated", Toast.LENGTH_SHORT).show()
    }

    fun goto_entry(view: View) {
        startActivity(Intent(this, TransactionLayotActivity::class.java))
        finish()
    }

    fun goto_graph(view: View) {
        startActivity(Intent(this, AnalyticsGraphsActivity::class.java))
        finish()
    }

    fun goto_lst(view: View) {
        startActivity(Intent(this, TransLstNdFilteringActivity::class.java))
        finish()
    }

    fun goto_rewards(view: View) {
        startActivity(Intent(this, ErrorPage::class.java))
        finish()
    }

    fun edit_savAcc(view: View){

    }
}

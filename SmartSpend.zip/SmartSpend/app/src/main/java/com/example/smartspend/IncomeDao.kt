package com.example.smartspend

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface IncomeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncome(transaction: IncomeTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncomes(transactions: List<IncomeTransactionEntity>)

    @Query("SELECT * FROM income_transactions ORDER BY id DESC")
    fun getAllIncome(): LiveData<List<IncomeTransactionEntity>>

    @Query("SELECT * FROM income_transactions WHERE userId = :userId")
    suspend fun getIncomeByUser(userId: String): List<IncomeTransactionEntity>

    @Query("DELETE FROM income_transactions WHERE id = :transactionId")
    suspend fun deleteIncomeById(transactionId: Int)
}

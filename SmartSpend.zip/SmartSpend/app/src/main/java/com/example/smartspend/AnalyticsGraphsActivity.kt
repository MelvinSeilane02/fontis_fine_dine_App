package com.example.smartspend

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.text.SimpleDateFormat
import java.util.*

class AnalyticsGraphsActivity : AppCompatActivity() {

    private lateinit var barChart: BarChart
    private lateinit var pieChart: PieChart
    private lateinit var lineChart: LineChart
    private lateinit var monthSpinner: Spinner
    private lateinit var logout: ImageButton

    private val months = listOf("All", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.analytics_graphs)

        barChart = findViewById(R.id.barChart)
        pieChart = findViewById(R.id.pieChart)
        lineChart = findViewById(R.id.lineChart)
        monthSpinner = findViewById(R.id.monthSpinner)
        logout = findViewById(R.id.LogoutBtn)

        logout.setOnClickListener {
            startActivity(Intent(this, MainActivity_dashboard::class.java))
            finish()
        }

        monthSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, months)
        monthSpinner.setSelection(0)

        monthSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: android.widget.AdapterView<*>,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                loadAllCharts(months[position])
            }

            override fun onNothingSelected(parent: android.widget.AdapterView<*>) {
                // Optional: handle if needed
            }
        }

        loadAllCharts("All")
    }

    private fun loadAllCharts(selectedMonth: String) {
        val db = Firebase.firestore
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        db.collection("users")
            .document(userId)
            .collection("transactions")
            .get()
            .addOnSuccessListener { result ->
                var totalIncome = 0f
                var totalExpense = 0f
                val incomeOverTime = mutableMapOf<String, Float>()
                val categoryDistribution = mutableMapOf<String, Float>()

                val formatter = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                for (doc in result) {
                    val type = doc.getString("type") ?: continue
                    val date = doc.getString("date") ?: continue
                    val category = doc.getString("category") ?: "Other"
                    val amount = doc.getString("amount")?.toFloatOrNull() ?: continue

                    val month = try {
                        val cal = Calendar.getInstance()
                        cal.time = formatter.parse(date) ?: continue
                        cal.get(Calendar.MONTH) + 1
                    } catch (e: Exception) { continue }

                    if (selectedMonth != "All" && months.indexOf(selectedMonth) != month) continue

                    if (type == "income") {
                        totalIncome += amount
                        val key = months[month]
                        incomeOverTime[key] = incomeOverTime.getOrDefault(key, 0f) + amount
                    } else if (type == "expense") {
                        totalExpense += amount
                        categoryDistribution[category] = categoryDistribution.getOrDefault(category, 0f) + amount
                    }
                }

                setupBarChart(totalIncome, totalExpense)
                setupPieChart(categoryDistribution)
                setupLineChart(incomeOverTime)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error loading data", Toast.LENGTH_SHORT).show()
            }
    }

    private fun setupBarChart(income: Float, expense: Float) {
        val entries = listOf(
            BarEntry(0f, income),
            BarEntry(1f, expense)
        )

        val dataSet = BarDataSet(entries, "Income vs Expense")
        dataSet.colors = listOf(Color.GREEN, Color.RED)
        dataSet.valueTextSize = 16f

        val barData = BarData(dataSet)
        barChart.data = barData
        barChart.xAxis.valueFormatter = IndexAxisValueFormatter(listOf("Income", "Expense"))
        barChart.description = Description().apply { text = "Total Income & Expenses" }
        barChart.animateY(1000)
        barChart.invalidate()
    }

    private fun setupPieChart(categoryData: Map<String, Float>) {
        val entries = categoryData.map { PieEntry(it.value, it.key) }
        val dataSet = PieDataSet(entries, "Expenses by Category")
        dataSet.colors = ColorTemplate.MATERIAL_COLORS.toList()
        dataSet.valueTextSize = 14f

        val pieData = PieData(dataSet)
        pieChart.data = pieData
        pieChart.description = Description().apply { text = "Category Distribution" }
        pieChart.animateY(1000)
        pieChart.invalidate()
    }

    private fun setupLineChart(incomeOverTime: Map<String, Float>) {
        val sortedEntries = incomeOverTime.toSortedMap().entries.mapIndexed { index, entry ->
            Entry(index.toFloat(), entry.value)
        }

        val dataSet = LineDataSet(sortedEntries, "Income Over Time")
        dataSet.color = Color.BLUE
        dataSet.valueTextSize = 14f
        dataSet.setCircleColor(Color.BLACK)

        val lineData = LineData(dataSet)
        lineChart.data = lineData
        lineChart.description = Description().apply { text = "Monthly Income" }
        lineChart.animateX(1000)
        lineChart.invalidate()
    }
}

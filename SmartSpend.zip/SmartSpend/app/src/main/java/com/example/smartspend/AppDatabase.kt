package com.example.smartspend

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [IncomeTransactionEntity::class, ExpenseTransactionEntity::class],
    version = 1)
abstract class AppDatabase : RoomDatabase() {

    // Connect DAO interface
    abstract fun incomeDao(): IncomeDao
    abstract fun expenseDao(): ExpenseDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smart_spend_db" // <- name of the local Room DB
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

package com.example.smartspend

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UtilityFun {
    /*fun getCurrentDate(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return formatter.format(Date())
    }*/

    companion object {
        fun getCurrentDate(): String  {
            val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            return formatter.format(Date())
        }
    }

}
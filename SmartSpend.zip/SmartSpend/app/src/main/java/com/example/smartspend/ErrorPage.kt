package com.example.smartspend

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.smartspend.databinding.ActivityErrorPageBinding

class ErrorPage : AppCompatActivity() {

    private lateinit var binding: ActivityErrorPageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityErrorPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    fun Back(view: View) {
        val intent = Intent(this, MainActivity_dashboard::class.java)
        startActivity(intent)
        finish()
    }
}

package com.example.smartspend

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class TransLstNdFilteringActivity : AppCompatActivity() {

    private lateinit var homeNav: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.trans_lst_nd_filtering) // 🔥 Moved before findViewById

        enableEdgeToEdge()

        // Safe to access views after setContentView
        homeNav = findViewById(R.id.homeBtn)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        homeNav.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    fun goto_rewards(view: View) {
        startActivity(Intent(this, ErrorPage::class.java))
        finish()
    }

    fun goto_entry(view: View) {
        startActivity(Intent(this, EntryFormActivity::class.java))
        finish()
    }

    fun goto_graph(view: View) {
        startActivity(Intent(this, AnalyticsGraphsActivity::class.java))
        finish()
    }
}

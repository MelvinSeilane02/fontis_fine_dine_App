package com.example.smartspend

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * A simple [androidx.fragment.app.Fragment] subclass.
 * Use the [Expense_layout.newInstance] factory method to
 * create an instance of this fragment.
 */
class Expense_layout : Fragment(R.layout.fragment_expense_layout) {

    private val tempTransactions = mutableListOf<ExpenseTransactionEntity>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /*Buttons*/
        val backBtn = view.findViewById<ImageButton>(R.id.backBtn)
        val AddmoreBtn = view.findViewById<Button>(R.id.add_another_btn)
        val saveBtn = view.findViewById<Button>(R.id.save_category_btn)
        val graph_btn = view.findViewById<LinearLayout>(R.id.graph_btn)
        val rewards_btn = view.findViewById<LinearLayout>(R.id.rewards_btn)
        val expenseLst_btn = view.findViewById<LinearLayout>(R.id.expenseLst_btn)
        /*------------------------------*/
        /*Input Requirements*/
        val dateTextView = view.findViewById<TextView>(R.id.expenseDateInput)
        val descipTextView = view.findViewById<EditText>(R.id.expenseDescripInput)
        val Categorydropdown = view.findViewById<AutoCompleteTextView>(R.id.expenseCategoryInput)
        val repeatAutoComplete: AutoCompleteTextView = view.findViewById(R.id.expenseRecurringInput)
        val AmountDropdown = view.findViewById<AutoCompleteTextView>(R.id.expenseAmountInput)
        /*------------------------------*/
        val categories = listOf("Food", "Transport", "Clothing", "Utilities")
        val repeatOptions = listOf("None", "Weekly", "Monthly", "Yearly")
        val amounts = listOf("10", "20", "50", "100", "200", "500", "1000")

        val switchBtn = view.findViewById<TextView>(R.id.income_btn)
        switchBtn.setOnClickListener {
            // Replace this fragment with Income_layout fragment
            parentFragmentManager.beginTransaction()
                .replace(R.id.transActContainer, Income_layout()) // your container id here
                .addToBackStack(null) // optional: adds to back stack for back button support
                .commit()

        }

        /*Back button*/
        backBtn.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
        /*----------------------*/
        /*For selecting amounts*/
        val AmtAdapter =
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, amounts)
        AmountDropdown.setAdapter(AmtAdapter)
        /*----------------------*/

        /*For selecting the date*/
        dateTextView.setOnClickListener {
            showDatePicker(dateTextView)
        }
        /*------------------------------*/

        /*For category*/
        val Categoryadapter =
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, categories)
        Categorydropdown.setAdapter(Categoryadapter)

        Categorydropdown.setOnItemClickListener { parent, _, position, _ ->
            val selectedType = parent.getItemAtPosition(position).toString()
            Toast.makeText(requireContext(), "Selected: $selectedType", Toast.LENGTH_SHORT).show()
        }
        /*------------------------------*/

        /*For Recurring trans*/
        val repeatAdapter =
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, repeatOptions)
        repeatAutoComplete.setAdapter(repeatAdapter)

        repeatAutoComplete.setOnItemClickListener { parent, _, position, _ ->
            val selectedType = parent.getItemAtPosition(position).toString()
            Toast.makeText(requireContext(), "Selected: $selectedType", Toast.LENGTH_SHORT).show()
        }
        /*------------------------------*/

        /*Add more button*/
        AddmoreBtn.setOnClickListener {
            handleAddTransaction(
                dateTextView,
                descipTextView,
                Categorydropdown,
                repeatAutoComplete,
                AmountDropdown,
                tempTransactions
            )
        }
        /*----------------------*/
        /*Save button */
        saveBtn.setOnClickListener {
            validateAndSaveTransaction(
                dateTextView,
                Categorydropdown,
                repeatAutoComplete,
                AmountDropdown,
                descipTextView
            )
        }
        /*----------------------*/
        graph_btn.setOnClickListener {
            navigateToErrorPage()
        }

        rewards_btn.setOnClickListener {
            navigateToErrorPage()
        }

        expenseLst_btn.setOnClickListener {
            navigateToErrorPage()
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_expense_layout, container, false)


    }

    fun goto_income_section(view: View) {}
    fun add_expense(view: View) {}
    fun save_expense(view: View) {}

    private fun showDatePicker(dateView: TextView) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        requireContext()

        val datePicker = DatePickerDialog(
            requireContext(),
            { _, selectedYear, selectedMonth, selectedDay ->
                val formattedDate = "${selectedDay.toString().padStart(2, '0')}/" +
                        "${(selectedMonth + 1).toString().padStart(2, '0')}/" +
                        "$selectedYear"
                dateView.text = formattedDate
            },
            year,
            month,
            day
        )

        datePicker.show()
    }

    private fun handleAddTransaction(
        dateView: TextView,
        descriptionInput: EditText,
        categoryInput: AutoCompleteTextView,
        repeatInput: AutoCompleteTextView,
        amountInput: AutoCompleteTextView,
        tempTransactions: MutableList<ExpenseTransactionEntity>
    ) {
        val date = dateView.text.toString()
        val description = descriptionInput.text.toString()
        val category = categoryInput.text.toString()
        val repeat = repeatInput.text.toString()
        val amount = amountInput.text.toString()
        //val transactionType = "Income" // or "Expense" depending on which screen you're on
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        if (date.isNotBlank() && description.isNotBlank() && category.isNotBlank() && repeat.isNotBlank() && amount.isNotBlank()) {

            val transaction = ExpenseTransactionEntity(
                transactionDate = date,
                category = category,
                repeat = repeat,
                amount = amount,
                description = description,
                userId = userId
            )

            tempTransactions.add(transaction)
            Toast.makeText(
                requireContext(),
                "Transaction added",
                Toast.LENGTH_SHORT
            ).show()

            // Optional clear fields after adding
            descriptionInput.text.clear()
            categoryInput.setText("")
            repeatInput.setText("")
            amountInput.setText("")
            dateView.text = "Select Date"

        } else {
            Toast.makeText(
                requireContext(),
                "Please fill in all fields correctly",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun validateAndSaveTransaction(
        dateTextView: TextView,
        Categorydropdown: AutoCompleteTextView,
        repeatAutoComplete: AutoCompleteTextView,
        AmountDropdown: AutoCompleteTextView,
        descipTextView: EditText
    ) {
        val date = dateTextView.text.toString().trim()
        val category = Categorydropdown.text.toString().trim()
        val repeat = repeatAutoComplete.text.toString().trim()
        val amount = AmountDropdown.text.toString().trim()
        val description = descipTextView.text.toString().trim()
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        if (tempTransactions.isEmpty()) {
            // 🚨 Basic validations
            when {
                date.isEmpty() -> {
                    dateTextView.error = "Date is required"
                    return
                }

                category.isEmpty() -> {
                    Categorydropdown.error = "Select a category"
                    return
                }

                amount.isEmpty() -> {
                    AmountDropdown.error = "Enter an amount"
                    return
                }

                description.isEmpty() -> {
                    descipTextView.error = "Enter a description"
                    return
                }
            }

            // ✅ Create transaction object
            val transaction = ExpenseTransactionEntity(
                transactionDate = date,
                category = category,
                repeat = repeat,
                amount = amount,
                description = description,
                userId = userId
            )

            // 💾 Save to RoomDB
            lifecycleScope.launch {

                AppDatabase.getDatabase(requireContext())
                    .expenseDao()
                    .insertExpense(transaction)

                Toast.makeText(
                    requireContext(),
                    "Expense saved!",
                    Toast.LENGTH_SHORT
                ).show()
                clearFormInputs(
                    dateTextView,
                    Categorydropdown,
                    repeatAutoComplete,
                    AmountDropdown,
                    descipTextView
                )

                return@launch
            }

            val db = AppDatabase.getDatabase(requireContext())
            val expenseDao = db.expenseDao()

            lifecycleScope.launch {
                expenseDao.insertExpenses(tempTransactions)  // or loop one by one if using insertExpense
                tempTransactions.clear() // Optional: clean up after saving
                Toast.makeText(requireContext(), "Saved to database", Toast.LENGTH_SHORT).show()

                val intent = Intent(requireContext(), MainActivity_dashboard::class.java)
                startActivity(intent)
                requireActivity().finish() // Optional: finish current Activity to prevent going back
            }

        }
    }

    private fun clearFormInputs(
        dateTextView: TextView,
        Categorydropdown: AutoCompleteTextView,
        repeatAutoComplete: AutoCompleteTextView,
        AmountDropdown: AutoCompleteTextView,
        descipTextView: EditText
    ) {
        dateTextView.text = ""
        Categorydropdown.setText("")
        repeatAutoComplete.setText("")
        AmountDropdown.setText("")
        descipTextView.text.clear()
    }

    private fun navigateToErrorPage() {
        val intent = Intent(requireContext(), ErrorPage::class.java)
        startActivity(intent)
        requireActivity().finish() // only if you want to kill the activity hosting this fragment
    }

}